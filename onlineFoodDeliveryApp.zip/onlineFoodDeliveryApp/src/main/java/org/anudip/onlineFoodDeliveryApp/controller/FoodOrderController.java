package org.anudip.onlineFoodDeliveryApp.controller;

import java.util.ArrayList;
import java.util.List;

import org.anudip.onlineFoodDeliveryApp.Dao.BillDao;
import org.anudip.onlineFoodDeliveryApp.Dao.CustomerDao;
import org.anudip.onlineFoodDeliveryApp.Dao.RestaurantDao;
import org.anudip.onlineFoodDeliveryApp.bean.Customer;
import org.anudip.onlineFoodDeliveryApp.bean.Restaurant;
import org.hibernate.internal.build.AllowSysOut;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@RestController
public class FoodOrderController {

    @Autowired
    private CustomerDao customerDao;
    @Autowired
    private RestaurantDao restaurantDao;
    

    @GetMapping("/index")
	public ModelAndView showIndexPage() {
		return new ModelAndView("index");
	}
    @GetMapping("/customerEntry")
	public ModelAndView showCustomerEntry() {
	ModelAndView mv = new ModelAndView("customerEntry");
	Integer newId = customerDao.generateNewCustomerId();
	Customer customer = new Customer(newId);
	mv.addObject("customerRecord", customer);
	return mv;
	}
	@PostMapping("/customerEntry")
	public ModelAndView saveUpdateCustomer(@ModelAttribute("customerRecord")Customer customer) {
	customerDao.saveCustomer(customer);
	return new ModelAndView("redirect:/index");
	}
	
	@GetMapping("/restaurantEntry")
	public ModelAndView showRestaurantEntry() {
	ModelAndView mv = new ModelAndView("restaurantEntry");
	String newId = restaurantDao.generateNewRestaurantId();
	Restaurant restaurant = new Restaurant(newId);
	mv.addObject("restaurantRecord", restaurant);
	return mv;
	}
	
	@PostMapping("/restaurantEntry")
	public ModelAndView saveUpdateRestaurant(@ModelAttribute("restaurantRecord")Restaurant restaurant) {
	restaurantDao.saveRestaurant(restaurant);
	return new ModelAndView("redirect:/index");
	}
		
	 // Code for "Customer List" page
    @GetMapping("/customerList")
    public ModelAndView showCustomerList() {
        ModelAndView mv = new ModelAndView("customerList");
       
        List<Customer> customerList = customerDao.displayAllCustomer(); // Assuming you have a method like displayAllCustomer in your CustomerDao
            mv.addObject("customerList", customerList);
            return mv;
        }
           
     // Code for "Restaurant List" page
    @GetMapping("/restaurantList")
    public ModelAndView showrestaurantList() {
        ModelAndView mv = new ModelAndView("restaurantList");
        List<Restaurant> restaurantList = restaurantDao.displayAllRestaurant(); 
        mv.addObject("restaurantList", restaurantList);
            return mv;
        }
         

  /*  // Code for "Bill Paid" page
    @GetMapping("/billPaid")
    public ModelAndView showbillPaid() {
        ModelAndView mv = new ModelAndView("billPaid");
        // Adding Of Logic still pending
        return mv;
    }
    
    // Code for "Order Booking" page
    @GetMapping("/orderBooking")
    public ModelAndView showorderBooking() {
        ModelAndView mv = new ModelAndView("orderBooking");
     // Adding Of Logic still pending
        return mv;
    }*/
}