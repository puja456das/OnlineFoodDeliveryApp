package org.anudip.onlineFoodDeliveryApp.Dao;

import java.util.List;

import org.anudip.onlineFoodDeliveryApp.bean.Order;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

@Service
@Repository
public class OrderDaoImpl implements OrderDao {
	@Autowired
	private OrderRepository repository;
	
	@Override
	public void saveOrder(Order order) {
		repository.save(order);

	}

	@Override
	public List<Order> displayAllOrder() {
		return repository.findAll();
	}

	@Override
	public Order findAOrderById(Long orderId) {
		return repository.findById(orderId).get();
	}
	
	@Override
	public Long generateNewOrderId() {
	    Long newId = 1L;
	    long val = repository.getOrderCount();
	    if (val == 1L)
	        newId = 1L;
	    else if (val > 1L) {
	        newId = 100L + (val);
	    }
	    return newId;
	}



}