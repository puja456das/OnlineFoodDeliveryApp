package org.anudip.onlineFoodDeliveryApp.service;

import java.util.Date;
import java.util.List;

import org.anudip.onlineFoodDeliveryApp.bean.Bill;
import org.anudip.onlineFoodDeliveryApp.bean.Customer;
import org.anudip.onlineFoodDeliveryApp.bean.Order;
import org.anudip.onlineFoodDeliveryApp.Dao.OrderDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


	@Service
	public class BillService {
	@Autowired
	private OrderDao orderDao;
		public double totalAmountCalculation(Customer customer) {
		int id=customer.getCustomerId();
		List<Order> orderList=orderDao.findOrdersByCustomerUnpaid(id,"U");
		double totalAmount=0.0;
		for (Order order:orderList) {
			totalAmount=totalAmount+order.getAmount();
		}
		return totalAmount;
			
		
		}
		
}