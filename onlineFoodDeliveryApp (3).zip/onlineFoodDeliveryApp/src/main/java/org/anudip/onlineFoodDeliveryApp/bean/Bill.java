package org.anudip.onlineFoodDeliveryApp.bean;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;



@Entity
public class Bill {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer serialNumber ;
	//private List <Order> orderList; 
	private Integer customerId; 
	//private String restaurantId;
	//private String itemName; 
	//private Integer quantity;
	//private Double amount;
	//private Date orderDate;
	//private String orderStatus;
	private Double amountPayable;
	//private String paymentStatus;
	public Bill() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Bill( Integer customerId, Double amountPayable) {
		super();
		
		this.customerId = customerId;
		this.amountPayable = amountPayable;
		//this.paymentStatus = paymentStatus;
	}
	public Bill(Integer serialNumber) {
		super();
		this.serialNumber = serialNumber;
	}
	public Integer getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(Integer serialNumber) {
		this.serialNumber = serialNumber;
	}
	public Integer getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}
	public Double getAmountPayable() {
		return amountPayable;
	}
	public void setAmountPayable(Double amountPayable) {
		this.amountPayable = amountPayable;
	}
	/*public String getPaymentStatus() {
		return paymentStatus;
	}
	public void setPaymentStatus(String paymentStatus) {
		this.paymentStatus = paymentStatus;
	}*/
	@Override
	public String toString() {
		return "serialNumber=" + serialNumber + ", customerId=" + customerId + ", amountPayable=" + amountPayable
				;
	}
}