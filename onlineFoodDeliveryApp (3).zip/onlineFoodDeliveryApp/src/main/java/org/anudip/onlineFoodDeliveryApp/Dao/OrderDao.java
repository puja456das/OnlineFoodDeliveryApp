package org.anudip.onlineFoodDeliveryApp.Dao;

import java.util.List;

import org.anudip.onlineFoodDeliveryApp.bean.Order;

public interface OrderDao {
	public void saveOrder(Order order); 
	public List<Order> displayAllOrder();
	public List<Order> findOrdersByCustomerUnpaid( Integer customerId,String payStatus);

	//public Order findAOrderById(Long orderId);

	public Long generateNewOrderId();
}
