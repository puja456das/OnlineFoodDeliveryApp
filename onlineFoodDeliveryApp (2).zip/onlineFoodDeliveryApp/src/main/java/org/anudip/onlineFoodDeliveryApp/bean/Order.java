package org.anudip.onlineFoodDeliveryApp.bean;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "orders")
public class Order {
	//@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Id
	private Long orderId;
	private Integer customerId;
	private String restaurantId;
	private String itemName;
	private Double quantity;
	private Double amount;
	private String orderDate;
	private String payStatus;
	//private Double gst;
	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Order(Long orderId, Integer customerId, String restaurantId, String itemName, Double quantity, Double amount,
			String orderDate, String payStatus) {
		super();
		this.orderId = orderId;
		this.customerId = customerId;
		this.restaurantId = restaurantId;
		this.itemName = itemName;
		this.quantity = quantity;
		this.amount = amount;
		this.orderDate = orderDate;
		this.payStatus = payStatus;
		//this.gst = gst;
	}
	public Order(Long orderId) {
		super();
		this.orderId = orderId;
	}
	public Long getOrderId() {
		return orderId;
	}
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}
	public Integer getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}
	public String getRestaurantId() {
		return restaurantId;
	}
	public void setRestaurantId(String restaurantId) {
		this.restaurantId = restaurantId;
	}
	public String getItemName() {
		return itemName;
	}
	public void setItemName(String itemName) {
		this.itemName = itemName;
	}
	public Double getQuantity() {
		return quantity;
	}
	public void setQuantity(Double quantity) {
		this.quantity = quantity;
	}
	public Double getAmount() {
		return amount;
	}
	public void setAmount(Double amount) {
		this.amount = amount;
	}
	public String getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}
	public String getPayStatus() {
		return payStatus;
	}
	public void setPayStatus(String payStatus) {
		this.payStatus = payStatus;
	}
	
	@Override
	public String toString() {
		return "orderId=" + orderId + ", customerId=" + customerId + ", restaurantId=" + restaurantId
				+ ", itemName=" + itemName + ", quantity=" + quantity + ", amount=" + amount + ", orderDate="
				+ orderDate + ", payStatus=" + payStatus;
	}
	
	
	}